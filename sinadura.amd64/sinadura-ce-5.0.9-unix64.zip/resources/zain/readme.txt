En este directorio hay que dejar el certificado de acceso a zain.
Se tiene que llamar zain.p12